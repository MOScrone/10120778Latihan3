package com.example.a10120778latihan3;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class WarningDialogActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_warning_dialog);
    }
}
// Nama                 : Syukur Ali Nurzaki
// NIM                  : 10120778
// Kelas                : IF-9
// Tanggal Pengerjaan   : 30-04-2023


